package com.example.formulariofase2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView TextView1;
    TextView TextView2;
    TextView TextView3;
    EditText Nombre;
    EditText Apellido;
    EditText Pais;
    Button REGRESAR;
    
    TextView editTextString;
            Button button;
            
            
    @Override
    
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        TextView1=findViewById(R.id.Nombre);
        TextView2=findViewById(R.id.Apellido);
        TextView3=findViewById(R.id.Pais);
        
        String Nombre = getIntent().getExtras().getString("Nombre");
        String Apellido = getIntent().getExtras().getString("Apellido");
        String Pais = getIntent().getExtras().getString("Pais");
        TextView1.setText(Nombre);
        TextView1.setText(Apellido);
        TextView1.setText(Pais);
        
        button = findViewById(R.id.REGRESAR);
        button.setOnClickListener(new View.OnClickListener) {
            
            public void onClick(View Object view;
            view) {
                Intent intent=new Intent(MainActivity2.this, MainActivity.class);
                startActivity(intent);
            }
            
        }
                

        
        
    }
}