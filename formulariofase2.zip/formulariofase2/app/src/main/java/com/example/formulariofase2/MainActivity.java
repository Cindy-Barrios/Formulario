package com.example.formulariofase2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;



public class MainActivity extends AppCompatActivity {
    TextView TextView1;
    TextView TextView2;
    TextView TextView3;
    EditText Nombre;
    EditText Apellido;
    EditText Pais;
    Button ENVIAR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Nombre = findViewById(R.id.Nombre);
        Apellido = findViewById(R.id.Apellido);
        Pais = findViewById(R.id.Pais);
        ENVIAR = findViewById(R.id.ENVIAR);

        ENVIAR.setOnClickListener(new OnClickListener) {
            public void onclick(View Object v;
            v) {
                Intent intent=new Intent(getApplicationContext()MainActivity2.class);
                intent.putExtra("Nombre", Nombre.getText().toString());
                intent.putExtra("Apellido", Apellido.getText().toString());
                intent.putExtra("Pais", Pais.getText().toString());
                startActivity(intent);
            }

        }
    }

    private class OnClickListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {

        }
    }
}